package controllers;



import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.Product;
import models.ProductRepository;


@WebServlet("/admin")
public class AdminServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            // Add a new product
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));
            String imagePath = request.getParameter("imagePath");

            Product newProduct = new Product(id, name, description, price, imagePath);
            ProductRepository.getAllProducts().add(newProduct);

        } else if ("edit".equals(action)) {
            // Edit an existing product
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));
            String imagePath = request.getParameter("imagePath");

            List<Product> products = ProductRepository.getAllProducts();
            for (Product product : products) {
                if (product.getId() == id) {
                    product.setName(name);
                    product.setDescription(description);
                    product.setPrice(price);
                    product.setImagePath(imagePath);
                    break;
                }
            }

        } else if ("delete".equals(action)) {
            // Delete a product
            int id = Integer.parseInt(request.getParameter("id"));
            List<Product> products = ProductRepository.getAllProducts();
            products.removeIf(product -> product.getId() == id);
        }

        response.sendRedirect("admin");
    }
}
