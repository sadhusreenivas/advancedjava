package models;


import java.util.ArrayList;
import java.util.List;

public class ProductRepository {
    private static List<Product> products = new ArrayList<>();

    static {
        products.add(new Product(1, "Laptop", "High-performance laptop.", 999.99, "images/compact.jpeg"));
        products.add(new Product(2, "Phone", "Smartphone with excellent features.", 499.99, "images/economy.jpeg"));
        products.add(new Product(3, "Headphones", "Noise-cancelling headphones.", 149.99, "images/standard.jpeg"));
    }

    public static List<Product> getAllProducts() {
        return products;
    }

    public static Product getProductById(int id) {
        return products.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }
}
